---
id: corpus-schema
title: "Evidence Corpus Schema"
kind: method
status: verified
last_updated: "2026-08-02"
evidence_track: lit
freshness: durable
sources: [FAIR-2016, W3C-PROV-O, RO-CRATE-1.2]
---

# Evidence Corpus Schema

This schema governs the active corpus. The inherited gingoa schema is preserved at
`../interpretation/legacy/gingoa-schema.md`; it no longer governs because it mixed evidence, project
application, and retrieval rules.

## 1. Layers and authority

| Layer | Purpose | May contain goppi decisions? | Mutable? |
|---|---|---:|---:|
| `corpus/methods/` | evidence and curation rules | no | yes, reviewed |
| `corpus/aspects/` | topic synthesis and claim registers | no | yes, reviewed |
| `corpus/census-data/` | raw or derived local empirical evidence | no | append-only |
| `imported/` | immutable historical source copies | historical content only | no |
| `interpretation/` | goppi conclusions, comparisons, and decisions | yes | yes |
| `audit/` | manifests, findings, dispositions, validation reports | no | append-only per audit |
| `archive/` | recoverable material removed from active retrieval | historical content only | no |

The active corpus is an **evidence base**, not a bag of “objective truth.” A claim is acceptable only when its
source, scope, evidence class, and uncertainty are visible. Source authority is always relative to the claim:
official product documentation is authoritative for a product's interface, not for the product's effectiveness.

## 2. Document types

- `_aspect.md`: bounded topic synthesis. It is not automatically normative and must not contain project-specific
  application decisions.
- `reference`: a focused, source-backed build or interface reference.
- `research-log`: search and extraction record; may contain unresolved conflicts.
- `evidence`: local empirical result or a stable pointer to raw data.
- `method`: corpus-wide research or curation rule.
- `navigation`: non-evidentiary index or crosswalk.

### 2.1 File naming — new files only (added 2026-08-08)

**Question first, date last.** `<question-topic>--<artifact>-<YYYY-MM>.md`
— e.g. `accessibility-obligations--facts-2026-08.md`, not `facts-2026-08-accessibility.md`.

Rationale: a filename is a retrieval surface. Front-loading `facts-2026-08-` spends the first 16 characters
on metadata that belongs in front matter, pushing the actual question past where a file-selection step reads.
Dates stay in the name **only** for append-only records (evaluation runs, incidents, snapshots), where the
date *is* the identity.

⚠️ **This applies to new and substantially-rewritten files only. Do NOT bulk-rename.**
Renaming is forbidden here for three measured reasons (2026-08-08 review): `validate_corpus.py` branches
required-key sets on the `_aspect.md` basename and asserts the 28-directory set; three ledgers carry paths as
values (`audit/after-manifest.tsv` 213 rows with SHA-256, `audit/CLAIM-REVALIDATION.ko.md`,
`audit/retrieval-cases.jsonl` 30 `expected_path`); and `ROUTES.jsonl` has **no stable id or former-path alias**,
so a rename severs document identity with nothing to detect it. The retrieval cost the rename would fix is
already recovered by the router's `question` field.

## 3. Required metadata

Every new curated Markdown document starts with YAML frontmatter containing:

```yaml
id: stable-kebab-id
title: "Human-readable title"
kind: reference              # aspect | reference | research-log | evidence | method | navigation
status: draft                # imported | draft | review-needed | verified | superseded | retracted
last_updated: "YYYY-MM-DD"
evidence_track: lit          # lit | census | census+lit | none
freshness: versioned         # durable | versioned | volatile
review_due: "YYYY-MM-DD"     # required for versioned/volatile material
sources: [SRC-ID]
```

Aspect documents keep their stable `aspect-NN-slug` ID plus `group`, `kind` (applicability),
`lifecycle_stages`, `anchors`, and `claim`. During the 2026-08 audit, inherited documents use
`status: review-needed` until their individual claims meet this schema.

## 4. Claim record

New or materially refreshed syntheses use a claim table:

| Claim ID | Class | Claim and scope | Evidence | Confidence | Valid as of / expiry |
|---|---|---|---|---|---|

Allowed classes:

- `definition`: a source's definition, attributed to it.
- `normative`: a requirement from a named standard or official specification; preserve MUST/SHOULD strength.
- `empirical`: an observation with population, sample, method, and limitations.
- `vendor-behavior`: current documented behavior of a named product/version.
- `synthesis`: a conclusion derived across sources; never presented as source text.
- `local-census`: a result from this corpus's data and code; prevalence is not quality.

Every claim cites one or more source IDs or a corpus evidence path. Conflicting results remain separate; they
are not averaged or silently reconciled. Exact quotations are exceptional and short.

## 5. Status semantics

- `imported`: immutable source copy, not endorsed.
- `draft`: incomplete collection or extraction.
- `review-needed`: inherited or changed synthesis whose claim-level support has not passed the current policy.
- `verified`: required metadata complete; each material claim traceable; source scope checked; conflicts and
  limitations stated; relevant validator checks pass; reviewer recorded.
- `superseded`: retained for history and linked to its replacement.
- `retracted`: known incorrect or unsafe to rely on; reason required.

`verified` is not permanent. A versioned source update, expiry trigger, contradicted claim, or material method
defect returns the document to `review-needed`.

## 6. Retrieval contract

Agents load progressively:

1. `INDEX.md` and its audit banner.
2. The relevant aspect's frontmatter, summary, and sub-document index.
3. Claim rows needed for the question.
4. Source-registry records and raw evidence only when validating or resolving a conflict.

Agents must not treat `review-needed`, `draft`, `imported`, `interpretation/`, or `archive/` as verified general
evidence. Retrieval status and evidence strength are filters, not prose hints.

## 7. Source registry and provenance

Canonical sources used by newly curated documents are registered in `_meta/sources.jsonl`. Each record includes
an ID, URL, publisher, source type, what it is authoritative for, access date, and freshness class. The registry
does not replace nearby citations; it prevents identity and version drift.

The optional export `ro-crate-metadata.json` may be generated when the research package is shared or archived.
RO-Crate is useful for packaging and provenance, but is not required for day-to-day Markdown authoring.

## 8. Mechanical validation

Run:

```sh
python3 .scratch/research/tools/validate_corpus.py
```

The validator checks active-file inventory, non-empty exact file and substantial-section repeats,
generated/dead artifacts, required aspect files, all `verified` frontmatter, registered source references,
claim rows in verified references, internal links, and legacy gingoa markers. The separate retrieval-contract
check verifies 30 pre-registered routes and bounded read surfaces. External-link reachability, semantic
duplication, model behavior, and claim truth require separate checks and are never inferred from a green
structural result.
