# goppi_final Engineering Evidence Corpus — INDEX

> **Agent entry point. Read this first, then load only the relevant aspect.** This is an evidence base, not a
> book of universal best practices. Most inherited aspect documents are `review-needed`; check frontmatter and
> claim scope before relying on them. Governing schema: [`_schema.md`](_schema.md). Evidence policy:
> [`methods/EVIDENCE-POLICY.md`](methods/EVIDENCE-POLICY.md). Korean guide: [`GUIDE.ko.md`](GUIDE.ko.md).
> Provisional taxonomy: [`TAXONOMY.md`](TAXONOMY.md). Navigation crosswalk: [`lifecycle.md`](lifecycle.md).
> Current audit and gaps: [`../audit/AUDIT.ko.md`](../audit/AUDIT.ko.md) ·
> [`../audit/GAPS.ko.md`](../audit/GAPS.ko.md). Raw local evidence: `census-data/`.

Framework coverage: [`framework-crosswalk-2026`](methods/framework-crosswalk-2026.md) — SWEBOK V4.0a,
ISO/IEC/IEEE 12207:2026, ISO/IEC 25010:2023, and all 28 aspects; ISO detailed clause mapping remains
`INCONCLUSIVE` without licensed full text.

Cross-cutting user axis: [`target-user-capability-model`](methods/target-user-capability-model.md) — outcome
expression, evidence/risk comprehension, technical verification, and operational responsibility.

Trustworthy-completion evidence: [`trustworthy-completion-evidence-model`](methods/trustworthy-completion-evidence-model.md)
— separates objective result, claim-linked assurance evidence, appropriate human reliance, recovery, and burden;
no universal goppi effect size is established.

## P — Plan & Design
- [`01` Requirements & Planning](aspects/01-requirements-planning/_aspect.md) — elicitation (Socratic) · functional + NFR (ISO-25010 sweep) · 29148 quality (full §5.2.5–5.2.6 well-formedness set) · EARS acceptance. _anchors:_ SWEBOK-KA1, ISO-29148, PMBOK7-Uncertainty.
- [`02` Architecture & Design](aspects/02-architecture-design/_aspect.md) _(cross-cutting)_ — architectural styles (layered/microservice/event/hexagonal) · ADRs (cross-cutting) · quality-attribute tactics. _anchors:_ SWEBOK-KA2, SWEBOK-KA3, ISO-12207-Architecture.

## F — Foundation & Build
- [`03` Dev Environment & Local Setup](aspects/03-dev-environment/_aspect.md) — reproducible local env (devcontainer/mise/Nix) · editorconfig · dev/prod parity & environment management. _anchors:_ SWEBOK-KA4, 12-Factor-I/II/X, devcontainer.
- [`04` Build & CI Engineering](aspects/04-build-ci-engineering/_aspect.md) _(cross-cutting)_ — CI pipeline (lint·typecheck·test·build) · build graph / affected (monorepo) · caching. _anchors:_ SWEBOK-KA4, SWEBOK-KA6, Accelerate.
- [`05` SCM & Development Workflow](aspects/05-scm-workflow/_aspect.md) _(cross-cutting)_ — branching (trunk / GitHub-flow) · Conventional Commits · CODEOWNERS. _anchors:_ SWEBOK-KA8, DORA-trunk, Conventional-Commits.
- [`06` Configuration & Secrets Management](aspects/06-config-secrets/_aspect.md) _(cross-cutting)_ — typed config + startup validation · feature flags · secret stores / rotation. _anchors:_ 12-Factor-III, NIST-SP-800-53-IA.

## C — Construct & Verify
- [`07` Software Construction & Code Review](aspects/07-construction-code-review/_aspect.md) — coding standards · code review (CL size / duties) · TDD. _anchors:_ SWEBOK-KA4, Google-eng-practices.
- [`08` Software Testing](aspects/08-software-testing/_aspect.md) _(cross-cutting)_ — unit / integration / e2e · contract testing (Pact) · property / mutation. _anchors:_ SWEBOK-KA5, ISO-25010, test-pyramid.
- [`09` Application Security](aspects/09-application-security/_aspect.md) _(cross-cutting)_ — threat modeling (STRIDE / DFD) · secure-by-design · authn / authz. _anchors:_ SWEBOK-KA13, OWASP-SAMM, OWASP-ASVS.
- [`10` Software Supply Chain Security](aspects/10-supply-chain-security/_aspect.md) _(cross-cutting)_ — SBOM (CycloneDX / SPDX) · provenance / attestation · artifact signing. _anchors:_ NIST-SSDF-PS, SLSA-v1.0, OpenSSF-Scorecard.
- [`28` Implementation Process & Agentic Workflow](aspects/28-implementation-process-workflow/_aspect.md) — risk/size process tailoring (tiering) · plan-then-act (plan as artifact) · lead-coordinator + context-isolated subagents. _anchors:_ SWEBOK-Process-KA, SWEBOK-Management-KA, ISO-12207-Tailoring.

## Q — Quality Attributes
- [`11` Maintainability, Tech Debt & Refactoring](aspects/11-maintainability-techdebt-refactoring/_aspect.md) _(cross-cutting)_ — debt register (ADR-tagged) · complexity / coupling metrics · refactoring discipline (Boy-Scout / strangler). _anchors:_ SWEBOK-KA7, ISO-25010-Maintainability.
- [`12` Performance & Scalability](aspects/12-performance-scalability/_aspect.md) _(gated: web, backend, data-ml, mobile, library)_ — perf budgets / benchmark · profiling · load / stress. _anchors:_ ISO-25010-Performance, ISO-25010-Flexibility, SRE-capacity.
- [`13` API & Interface Design](aspects/13-api-interface-design/_aspect.md) _(gated: library, cli, backend)_ — REST / GraphQL / gRPC design · versioning & breaking-change gate · idempotency. _anchors:_ SWEBOK-KA2, SWEBOK-KA3, OpenAPI.
- [`14` Data Management & Migrations](aspects/14-data-management-migrations/_aspect.md) _(gated: backend, data-ml)_ — schema / data migrations (Flyway/Alembic) · zero-downtime / expand-contract · data modeling. _anchors:_ ISO-12207-Implementation, ISO-12207-Maintenance, expand-contract.
- [`15` Accessibility & UX / Interaction Capability](aspects/15-accessibility-ux/_aspect.md) _(gated: web, mobile)_ — WCAG POUR / AA · semantic HTML / ARIA · keyboard / screen-reader. _anchors:_ ISO-25010-Interaction-Capability, WCAG-2.2, EN-301-549.
- [`16` Privacy & Data Protection](aspects/16-privacy-data-protection/_aspect.md) _(gated: handles-user-data)_ — privacy-by-design · data minimization · DSAR / erasure / portability. _anchors:_ GDPR-Art-25, ISO-25010-Security, NIST-Privacy.

## R — Release & Operate
- [`17` Release Engineering](aspects/17-release-engineering/_aspect.md) — SemVer · changelog automation · CI/CD gates. _anchors:_ SemVer-2.0, Conventional-Commits, Keep-a-Changelog.
- [`18` Packaging & Distribution](aspects/18-packaging-distribution/_aspect.md) — registry publish (npm/PyPI/crates/Maven) · binary distribution (Homebrew/winget/goreleaser) · container / Helm publish. _anchors:_ npm-provenance, SLSA, Homebrew.
- [`19` Observability & Telemetry](aspects/19-observability-telemetry/_aspect.md) — metrics (RED / USE) · structured logs · distributed tracing. _anchors:_ OpenTelemetry, SRE-golden-signals.
- [`20` Operations, Incident & Reliability](aspects/20-operations-incident-reliability/_aspect.md) — SLO + error-budget policy · on-call / escalation · incident response. _anchors:_ Google-SRE, ITIL-4, DORA.
- [`21` Software Economics, Cost & Sustainability](aspects/21-economics-cost-sustainability/_aspect.md) _(gated: cloud, published)_ — cost visibility / tagging · budget alerts · rightsizing / commitments. _anchors:_ SWEBOK-KA15, FinOps-Framework, GSF-SCI.

## G — Cross-cutting Practice & Governance
- [`22` Documentation & Knowledge Management](aspects/22-documentation-knowledge/_aspect.md) _(cross-cutting)_ — Diátaxis 4-mode · README / CONTRIBUTING / SECURITY / CHANGELOG · ADR records. _anchors:_ Diataxis, IEEE-ISO-15289, docs-as-code.
- [`23` Developer Experience & Onboarding](aspects/23-developer-experience/_aspect.md) _(cross-cutting)_ — onboarding runbook · time-to-first-PR · golden paths / paved road. _anchors:_ CNCF-Platform-Eng-MM, DORA-platform, SPACE.
- [`24` Governance, Collaboration & Compliance](aspects/24-governance-collaboration-compliance/_aspect.md) _(cross-cutting)_ — issue / triage · contribution policy / CoC · decision rights (RACI). _anchors:_ ISO-12207-Org, SWEBOK-KA9, SWEBOK-KA14.
- [`25` Licensing & FOSS Compliance](aspects/25-licensing-foss-compliance/_aspect.md) _(cross-cutting)_ — license selection / compatibility (inbound/outbound) · SPDX identifiers / REUSE · dependency license scanning. _anchors:_ SPDX-2.3, REUSE-2.0, OpenChain-ISO-5230.

## S — Specialized Archetype
- [`26` MLOps / ML Lifecycle](aspects/26-mlops-ml-lifecycle/_aspect.md) _(gated: data-ml)_ — data versioning (DVC / Delta) · experiment tracking (MLflow / W&B) · feature store (Feast). _anchors:_ ml-ops.org-Stack-Canvas, MLOps-literature.
- [`27` AI-Harness Archetype](aspects/27-ai-harness-archetype/_aspect.md) _(internal / gated: ai-harness)_ — agent orchestration (planner / impl / review) · prompt engineering + versioning · evals / eval-harness. _anchors:_ Anthropic-MCP, Agent-Skills, AGENTS.md.

## Deep-dive sub-documents (fetch when an aspect needs depth — these are the definitive standards)
- **01 Requirements & Planning** — [`planning-document-family`](aspects/01-requirements-planning/planning-document-family.md) (the PRD/spec doc KINDS · sections · naming · location · publish) · [`decision-record-standard`](aspects/01-requirements-planning/decision-record-standard.md) (ADR sections + IS/ISN'T-an-ADR rubric) · [`elicitation-interview-build-standard`](aspects/01-requirements-planning/elicitation-interview-build-standard.md) (the US-2 interview-engine build standard, 7 prior-art families) · [`requirements-engineering-craft`](aspects/01-requirements-planning/requirements-engineering-craft.md) (traceability · validation · DoR · prioritization) · [`constitution-authoring-standard`](aspects/01-requirements-planning/constitution-authoring-standard.md) (`AGENTS.md`/`CLAUDE.md`) · [`elicitation-prior-art`](aspects/01-requirements-planning/elicitation-prior-art.md) · [`planning-output-census`](aspects/01-requirements-planning/planning-output-census.md) (*census*: 267-repo planning-artifact prevalence) · [`brownfield-planning-adoption`](aspects/01-requirements-planning/brownfield-planning-adoption.md) (the `adopt` ①-plan slice: import / convert / reverse-engineer existing requirements)
- **04 Build & CI** — [`foundation-floor-artifact-checklist`](aspects/04-build-ci-engineering/foundation-floor-artifact-checklist.md) (**the canonical ② foundation output contract**: floor file set × location × push × repo-context conditioning — the ② analogue of `planning-document-family`) · [`visibility-provision-matrix`](aspects/04-build-ci-engineering/visibility-provision-matrix.md) (private↔public enablement flips) · [`brownfield-adoption-floor`](aspects/04-build-ci-engineering/brownfield-adoption-floor.md) (the `adopt` ②-foundation slice: audit-mode · 3-way disposition · ownership baseline · relaxed green-gate)
- **05 SCM & GitHub Workflow** — [`github-workflow-current`](aspects/05-scm-workflow/github-workflow-current.md) (**current verified map**: GitHub Flow/product facts, bounded defaults, risk-scaled controls)
- **17 Release** — [`release-operate-artifact-checklist`](aspects/17-release-engineering/release-operate-artifact-checklist.md)
- **22 Documentation** — [`content-ci-linting-and-jargon-gate`](aspects/22-documentation-knowledge/content-ci-linting-and-jargon-gate.md)
- **27 AI-Harness** — [`harness-control-plane-standard`](aspects/27-ai-harness-archetype/harness-control-plane-standard.md) (**current verified map**: control/capability/execution/state/assurance/distribution planes) · [`agent-threat-model`](aspects/27-ai-harness-archetype/agent-threat-model.md) (**current verified integrated threat map**: injection/authority/credential/filesystem/egress/state/production/recovery) · inherited `review-needed` references: [`skill-authoring-standard`](aspects/27-ai-harness-archetype/skill-authoring-standard.md) · [`mcp-server-standard`](aspects/27-ai-harness-archetype/mcp-server-standard.md) · [`hooks-commands-subagents-standard`](aspects/27-ai-harness-archetype/hooks-commands-subagents-standard.md) · [`plugin-marketplace-memory-standard`](aspects/27-ai-harness-archetype/plugin-marketplace-memory-standard.md) · [`prompts-and-evals-standard`](aspects/27-ai-harness-archetype/prompts-and-evals-standard.md) · [`host-config-schemas`](aspects/27-ai-harness-archetype/host-config-schemas.md)
- **28 Implementation** — [`research-log`](aspects/28-implementation-process-workflow/research-log.md) (the process / agentic-workflow `[lit]` backbone)
- **2026-08 facts passes (ko)** — thirty-three facts-only sub-docs (`facts-2026-08-*.md`, per-claim URLs + source-tier tags), in five passes:
  - *08-02 base pass* (11 docs) — aspects 01(×2)·02·04·07·08·09·20·24·28(×2); cross-aspect navigation + figure-discrepancy list: [`facts-2026-08-matrix.md`](facts-2026-08-matrix.md)
  - *08-02 R0-8 agent-steering pass* (4 docs) — [`27` steering-mechanisms](aspects/27-ai-harness-archetype/facts-2026-08-steering-mechanisms.md) · [`27` instruction-adherence](aspects/27-ai-harness-archetype/facts-2026-08-instruction-adherence.md) · [`27` compliance-verification](aspects/27-ai-harness-archetype/facts-2026-08-compliance-verification.md) · [`28` agent-workflow-prescriptions](aspects/28-implementation-process-workflow/facts-2026-08-agent-workflow-prescriptions.md)
  - *08-05 boundary & duty pass* (6 docs, R3 — 남은 미검증 축) — [`15` accessibility-obligations](aspects/15-accessibility-ux/facts-2026-08-accessibility-obligations.md) · [`16` privacy-statutory-duties](aspects/16-privacy-data-protection/facts-2026-08-privacy-statutory-duties.md) (**PIPA 제30조 각 호 원문 확보**) · [`12` web-performance-thresholds](aspects/12-performance-scalability/facts-2026-08-web-performance-thresholds.md) · [`21` serverless-cost-model](aspects/21-economics-cost-sustainability/facts-2026-08-serverless-cost-model.md) · [`13` api-scope-boundary](aspects/13-api-interface-design/facts-2026-08-api-scope-boundary.md) · [`24` solo-governance-handover](aspects/24-governance-collaboration-compliance/facts-2026-08-solo-governance-handover.md). **횡단 발견**: ① Core Web Vitals·성능 예산·FinOps도 **표준이 아닌 처방** ② **어느 플랫폼도 "성능=비용"을 규정하지 않는다**(과금 단위가 제각각) ③ **RFC 9110·OpenAPI는 공개/내부 API를 구분하지 않는다** ④ **개발자 인계에 공식 표준이 팀 규모와 무관하게 없다**
  - *08-05 craft-layer pass* (8 docs, R2 — 시니어 인계 가능성 축) — [`03` reproducible-environment](aspects/03-dev-environment/facts-2026-08-reproducible-environment.md) · [`06` config-validation-secrets](aspects/06-config-secrets/facts-2026-08-config-validation-secrets.md) · [`19` structured-logging-metrics](aspects/19-observability-telemetry/facts-2026-08-structured-logging-metrics.md) · [`22` repo-docs-adr-runbook](aspects/22-documentation-knowledge/facts-2026-08-repo-docs-adr-runbook.md) · [`11` refactoring-debt-discipline](aspects/11-maintainability-techdebt-refactoring/facts-2026-08-refactoring-debt-discipline.md) · [`10` dependency-updates-scope](aspects/10-supply-chain-security/facts-2026-08-dependency-updates-scope.md) · [`14` migration-discipline](aspects/14-data-management-migrations/facts-2026-08-migration-discipline.md) · [`25` license-obligations](aspects/25-licensing-foss-compliance/facts-2026-08-license-obligations.md). **두 가지 횡단 발견**: ① 12-Factor·RED/USE·Diátaxis·Keep a Changelog·ADR·SRE runbook은 **표준 기관 산출물이 아닌 처방**이다 ② SLSA·Scorecard·SBOM은 **자체 호스팅 웹 앱 적용을 명시하지 않는다**
  - *08-04 web-app archetype pass* (4 docs, GAPS R1-9/10/11) — [`20` solo-operations-minimum](aspects/20-operations-incident-reliability/facts-2026-08-solo-operations-minimum.md) (managed 플랫폼에서 1인 소유자에게 남는 운영 책임) · [`17` last-mile-domain-hosting](aspects/17-release-engineering/facts-2026-08-last-mile-domain-hosting.md) · [`17` last-mile-payments-privacy](aspects/17-release-engineering/facts-2026-08-last-mile-payments-privacy.md) (공개·수익화의 승인 지점과 사람만 할 수 있는 단계) · [`04` web-scaffold-baseline](aspects/04-build-ci-engineering/facts-2026-08-web-scaffold-baseline.md) (인증·RLS·시크릿·CI·에러추적의 공식 규정과 침묵의 위험 지점)

---
_Stable paths do not imply verified claims. The 2026-08-02 audit downgraded inherited syntheses to
`review-needed`; the P0 claim-level revalidation backlog is authoritative._
