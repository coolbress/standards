---
id: aspect-27-ai-harness-archetype--multi-agent-orchestration-standard
title: "Multi-agent orchestration — the topology/when-to-dispatch standard (orchestrator-worker, single-writer, model-routing)"
parent: aspect-27-ai-harness-archetype
kind: reference
evidence_track: census+lit
status: verified
last_updated: "2026-07-02"
sources:
  - "https://www.anthropic.com/engineering/built-multi-agent-research-system"
  - "https://code.claude.com/docs/en/agent-sdk/subagents"
  - "https://cognition.com/blog/dont-build-multi-agents"
  - "https://cognition.com/blog/multi-agents-working"
  - "https://openai.github.io/openai-agents-python/"
  - "https://developers.openai.com/codex/subagents"
  - "https://developers.openai.com/codex/changelog"
  - "https://arxiv.org/html/2602.16873v1"
  - "https://arxiv.org/html/2509.07571v1"
---

> **Standard (claim):** The dominant production multi-agent topology is **orchestrator-worker with context isolation** — a capable lead decomposes a task, dispatches specialized workers in parallel that each run in their **own context window** and return only a condensed result, and the lead synthesizes. It delivers a large quality lift on the right tasks (Anthropic: **+90.2%** on a research eval) at a **~15× token cost**, so it is justified only for **high-value, read-heavy, genuinely-decomposable** work. The hard boundary is **Cognition's single-writer principle**: parallel workers may *contribute intelligence* but **writes stay single-threaded** — parallel writers to shared state produce conflicting *implicit* decisions and incoherent output.
> **Evidence:** lit (Anthropic eng, Cognition, OpenAI/Claude Code docs, MoA arXiv) + the cross-vendor convergence of Claude Code + Codex on the same subagent primitive. **Confidence:** high. **Kind:** reference / gated[ai-harness]. **Complements** [`hooks-commands-subagents-standard.md`](hooks-commands-subagents-standard.md) (how to author *one* subagent) with *how to compose many / when to dispatch at all*.

## Why this sub-doc (vs the component standard)
`hooks-commands-subagents-standard.md` covers the *component* — authoring a single subagent (`.claude/agents/*.md`, context isolation, the when-to-use-a-subagent matrix). This sub-doc is the *strategy* layer above it: the named orchestration **topologies**, the **decision rule** for when an orchestrator + parallel workers actually helps vs hurts, the **token-cost reality**, **heterogeneous model routing**, and the **cross-host (CC/Codex) dispatch parity** as of mid-2026.

## Named topologies (comparison)

| Pattern | Coordination primitive | Context model | Coupling | Parallel? | Representative impl |
|---|---|---|---|---|---|
| **Orchestrator-worker** | lead dispatches + synthesizes | isolated windows, summary return | low | yes | Anthropic Research; Claude Code subagents; OpenAI "agents-as-tools" |
| **Supervisor** | central router, control always returns | shared state or per-call | medium | partial | LangGraph Supervisor |
| **Handoff / swarm** | peer-to-peer control transfer | history passed on handoff | variable | no | OpenAI Agents-SDK handoffs; LangGraph Swarm |
| **Group-chat** | turn-taking broadcast, all see all | fully shared transcript | high | no | AutoGen GroupChat |
| **Hierarchical** | multi-level manager chains | manager sees all; workers bounded | medium | partial | CrewAI hierarchical |
| **Generator-verifier** | write, then **read-only** independent review | reviewer context *intentionally limited* | low (by design) | no | **Cognition's endorsed pattern** |
| **Blackboard** | shared data structure, any agent r/w | fully shared persistent state | high | yes (locks) | LangGraph state |
| **Model-routing / MoA** | orchestrator routes to a specialist *model* | query + result only | very low | yes | Anthropic Opus→Sonnet; per-task model |

## The decision rule (when orchestrator+parallel-workers helps)
**Use it only when ALL hold** (else prefer a single-threaded agent with good context):
1. Task **decomposes into independent sub-problems** that don't need each other's *intermediate* decisions (research: explore A vs B ✅; edit one shared codebase ❌).
2. Sub-problems are **read/analysis-heavy** (gather, review, validate, summarize). **Writing to shared state is the danger zone.**
3. Total information **exceeds one context window**, or sequential traversal is prohibitively slow (multi-agent buys parallelism *and* context capacity).
4. Task value **justifies the ~15× token cost** (Anthropic states this explicitly; not economically rational for cheap tasks).
5. You accept workers make **implicit decisions**; if those can conflict, you need the single-writer constraint or scoping that prevents conflict.

**Do NOT use it when:** tasks share mutable state · the task needs tight real-time coordination ("LLM agents are not yet great at coordinating/delegating in real time" — Anthropic) · a finding from A must reshape B mid-flight (isolation defeats it) · token budget is tight · the task is simple/fast (coordination overhead not repaid).

## The single-writer principle (Cognition — the load-bearing caveat)
Cognition ("Don't Build Multi-Agents", 2024 → "Multi-Agents: What's Actually Working", 2025), from production coding: **"actions carry implicit decisions, and conflicting decisions carry bad results."** Two parallel agents editing shared code each make micro-decisions invisible to the peer → incoherent result (the Flappy-Bird example). Revised rule: **multi-agent works when writes stay single-threaded and extra agents contribute *intelligence*, not *actions*.** Three patterns they endorse in production:
1. **Generator-verifier loop** — a coding agent produces; a **separate read-only reviewer** audits *without* the author's context. Counterintuitively the reviewer's *shorter/limited* context **improves** bug detection (they report ~2 more bugs/PR, 58% severe) by cutting "context rot". Read-only multi-agent.
2. **Cross-frontier model routing** — pair e.g. Claude + a GPT-class model as peer specialists (capability optimization, not cost).
3. **Hierarchical delegation** — manager coordinates, children execute bounded scopes, manager synthesizes.
Core principle: **"reliability is context engineering"** — what each agent *knows* matters more than the infrastructure pattern.

## Token / performance reality (Anthropic, 2025-06)
- Single agent ≈ **4×** a chat's tokens; multi-agent ≈ **15×**.
- "Token usage by itself explains **80%** of the [performance] variance"; three factors explain 95%.
- Multi-agent (Opus lead + Sonnet workers) beat single-agent Opus by **+90.2%** on their internal research eval.
- Wins: breadth-first, parallelizable, info-exceeds-one-window, many complex tools. Loses: shared-context / many inter-agent dependencies / most coding (fewer truly parallel subtasks).

## Heterogeneous model routing
- **Production norm = large orchestrator, small workers** (Anthropic: Opus 4 lead, Sonnet 4 workers). Claude Code exposes this via a **per-subagent `model` field**; Codex custom agents take an optional `model`.
- **Mixture-of-Agents (MoA)** formalizes routing per task type: *Towards Generalized Routing* (arXiv 2509.07571, 2025-09); *AdaptOrch* (arXiv 2602.16873, 2026-02) — as frontier-model capability converges, *composition* dominates *model choice*; *Beyond Monoliths / Expert Orchestration* (arXiv 2506.00051).
- **State mid-2026:** production systems use **static role assignment**; **dynamic per-query routing** is still mostly research.

## Cross-host dispatch parity (CC vs Codex, mid-2026) — VERIFIED, corrects a stale prior
Both hosts now have a first-class subagent/delegation primitive — **this is a change**: Codex added it in **June 2026** (do not assume "Codex has no subagents").

| Dimension | Codex (Codex CLI v0.142.0, 2026-06-22) | Claude Code |
|---|---|---|
| Delegation trigger | **explicit-request-only by default** (proactive is an opt-in thread/turn setting) | proactive **+** explicit |
| Built-ins | `default` / `worker` / `explorer` | Explore / Plan / general-purpose |
| Custom def | `developer_instructions` (+ optional `model`/`sandbox`/`tool`) | markdown + YAML frontmatter (`description`/`prompt`/`tools`/`model`/`hooks`/`skills`/`isolation`…) |
| Context isolation | inherits parent sandbox | **fresh window; only final message returns** |
| Parallel | yes (batch/multi-aspect) | yes (fg/bg) |
| Nesting | not documented | **up to 5 levels** (v2.1.172) |
| MCP-as-service | **`codex mcp-server`** exposes Codex as an MCP server (`codex()`/`codex-reply()`) → an outer orchestrator can call Codex as a subprocess | not a service (Agent-SDK for programmatic use) |
| Maturity | new (2026-06) | mature |

Sources: [Codex changelog](https://developers.openai.com/codex/changelog) · [Codex subagents](https://developers.openai.com/codex/subagents) · [Codex + Agents SDK](https://developers.openai.com/codex/guides/agents-sdk) · [Claude Code subagents](https://code.claude.com/docs/en/sub-agents) · [Agent-SDK subagents](https://code.claude.com/docs/en/agent-sdk/subagents). *(Codex figures are from a single 2026-07-02 web-research pass — re-verify version/date if a decision is load-bearing on them.)*

## Implications for gingoa
- **gingoa's own dev-loop already IS orchestrator-worker** (ADR-0013 row 28 `S(lead → sub-agent delegation, plan-as-artifact)`): planner → implementer → adversarial reviewers, each context-isolated with handoff artifacts (plan / diff / verdict). This research is the external grounding + boundary conditions for that, not a new direction.
- **The adversarial reviewer = the generator-verifier pattern** — Cognition's #1 endorsed production pattern. It is deliberately **read-only, returns findings, does not write**; the lead remains the single writer. A fresh/limited-context verifier is *empirically better* at breaking claims than the model that authored the artifact.
- **Reserve dispatch for high-value gates, not routine steps.** The 15× cost means multi-agent is for the elicit skeptic / architecture review / release audit — not every incremental edit. Routine writing stays single-threaded (ADR-0013 locus).
- **Deterministic core is the coordination substrate, not another agent.** gingoa keeps the *enforcement* (gates, lock, seal) in model-call-free `core`/CLI — host-neutral — so a dispatched worker's *judgment* is host-side while its *consequences* are enforced identically on both hosts. This sidesteps the coordination-in-real-time weakness the literature flags.
- **Cross-host delivery:** gingoa ships the *prompt artifact* (skill / agent definition); each host dispatches it (CC subagent; Codex subagent since 2026-06, or inline). Parity is preserved by keeping the shipped unit host-neutral and the enforcement in core — **not** by betting on either host's dispatch primitive.

## Sources
- Anthropic — How we built our multi-agent research system (2025-06-13) — https://www.anthropic.com/engineering/built-multi-agent-research-system
- Claude Code Agent-SDK subagents — https://code.claude.com/docs/en/agent-sdk/subagents · https://code.claude.com/docs/en/sub-agents
- Cognition — Don't Build Multi-Agents (2024) — https://cognition.com/blog/dont-build-multi-agents · Multi-Agents: What's Actually Working (2025) — https://cognition.com/blog/multi-agents-working
- OpenAI Agents SDK — https://openai.github.io/openai-agents-python/ · orchestration/handoffs — https://developers.openai.com/api/docs/guides/agents/orchestration · Swarm — https://github.com/openai/swarm
- OpenAI Codex — changelog https://developers.openai.com/codex/changelog · subagents https://developers.openai.com/codex/subagents · Agents-SDK integration https://developers.openai.com/codex/guides/agents-sdk
- LangGraph supervisor/swarm — https://dev.to/focused_dot_io/multi-agent-orchestration-in-langgraph-supervisor-vs-swarm-tradeoffs-and-architecture-1b7e · AWS+Bedrock — https://aws.amazon.com/blogs/machine-learning/build-multi-agent-systems-with-langgraph-and-amazon-bedrock/
- CrewAI — https://docs.crewai.com/en/concepts/tasks · AutoGen — https://microsoft.github.io/autogen/0.2/docs/tutorial/conversation-patterns/
- MoA / routing — Towards Generalized Routing (arXiv 2509.07571) · AdaptOrch (arXiv 2602.16873) · Beyond Monoliths / Expert Orchestration (arXiv 2506.00051)
- Simon Willison — notes on Anthropic multi-agent system — https://simonwillison.net/2025/Jun/14/multi-agent-research-system/
