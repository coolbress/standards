---
id: aspect-17-release-engineering
title: "Release Engineering"
group: "R — Release & Operate"
kind: universal
gated_archetypes: []
cross_cutting: false
lifecycle_stages: ["④"]
anchors: ["SemVer-2.0", "Conventional-Commits", "Keep-a-Changelog", "DORA"]
evidence_track: census+lit
status: verified
last_updated: "2026-06-25"
sources:
  - "https://semver.org/"
  - "https://www.conventionalcommits.org/en/v1.0.0/"
  - "https://keepachangelog.com/en/1.1.0/"
  - "https://dora.dev/guides/dora-metrics-four-keys/"
  - "https://cloud.google.com/devops"
  - "https://getdx.com/blog/2024-dora-report/"
claim: "Senior teams ship via automated, SemVer-tagged releases driven from Conventional-Commits history (release-notes + CHANGELOG generated, not hand-written), with deployment/rollback rigor scaled to the archetype and delivery health tracked against DORA — release discipline is near-universal, operational depth is archetype-conditional."
gingoa_applied: "docs/PRD.md"
maps_from: ["census-data/census-release-ops"]
---

> **Standard (claim):** Senior teams ship via **automated, SemVer-tagged releases driven from Conventional-Commits history** (notes + CHANGELOG generated, not hand-written); deployment/rollback rigor scales to the **archetype**, and delivery health is tracked against **DORA** — release discipline is near-universal, operational depth is archetype-conditional.
> **Evidence:** 429-repo census (Releases/Tags API + commit sampling + tree flags) + DORA/SemVer/CC/Keep-a-Changelog `[lit]` · **Confidence:** high (release half hard-measured; ops half cross-validated against surveys) · **Kind:** universal · **Stage:** ④

**Seed sub-aspects:** `SemVer` · `changelog automation` · `CI/CD gates` · `deployment strategies (blue-green / canary)` · `progressive delivery & feature-flag lifecycle` · `rollback` · `env promotion` · `PRRs`

## What professional engineers do

- **SemVer versioning** `[lit][census]`. Every release is a `vMAJOR.MINOR.PATCH` tag; major = breaking, minor = additive, patch = fixes. Near-mandatory: **86% (uniform) / 80% (weighted)** of repos tag SemVer, tag-level conformance `semver_ratio` weighted-mean **0.72**. The harness SemVer-tags every release by default.
- **Release automation + notes** `[lit][census]`. A release workflow cuts a **tagged GitHub Release with notes** — not a manual upload. **89/86%** publish tagged releases, **88/85%** ship notes alongside. Tooling (semantic-release / release-please / changesets / goreleaser) is a `[lit]` default — the census measured the *outcome* (a published release), not which tool.
- **Conventional Commits as the engine** `[lit][census]`. Commit history (`feat:`, `fix:`, `BREAKING CHANGE:`) is the single source that *derives* the next SemVer bump, the changelog, and the release notes — no hand-curation. Behavioral commit-sampling shows **45% uniform / 67% weighted** actually follow CC (vs only 14% that merely *install* commitlint-style tooling) — the **fastest-rising ④ signal (+22 weighted)**.
- **Changelog (Keep a Changelog)** `[lit][census]`. A human-readable `CHANGELOG.md` (Added/Changed/Fixed/Removed, newest-first, "Unreleased" section) — ideally generated from CC history. **55/52%** maintain one; strongest for library/cli/published artifacts, optional for internal services.
- **Release cadence** `[census]`. Median **7 days** between releases (n=378 with ≥2 releases) — a proxy for DORA *deployment frequency*; mature OSS releases roughly **weekly**.
- **CI/CD gates + deployment** `[lit][census]`. Release candidates are green increments; CD/publish workflows promote them. **64/68%** run a CD/deploy-or-publish workflow; **53/62%** containerize. Progressive-delivery patterns (blue-green, canary, feature-flag-gated rollout) and **environment promotion** (dev→staging→prod) apply where a live service exists `[lit]`.
- **Rollback / recoverability** `[lit]`. A defined revert path (`git revert`, redeploy-previous-tag, flag-kill) so a bad release is reversible without history rewrite — a DORA *failed-deployment-recovery* lever; `[lit]` posture (rarely a repo file).
- **IaC + observability-as-code** `[census]`. Infra-as-code (Terraform/k8s/helm) at **28/29%** and observability-as-code (otel/prometheus/SLO yaml) at **18/17%** — a sparse, archetype-driven tail; real monitoring/SLOs live outside the repo (Grafana/Datadog/PagerDuty).
- **Delivery-health measurement (DORA / PRRs)** `[lit]`. Teams track the **Four Keys** (deploy frequency, change lead time, change-failure rate, recovery time) + reliability; production-readiness reviews (PRRs) gate a service's first ship. These are *achievement* metrics measured by survey, not repo census.

## Evidence (lit + census)

- **SemVer 2.0.0** — `vMAJOR.MINOR.PATCH` contract `[lit]` (https://semver.org/). Census: `semver_any` **86/80**, `semver_ratio` wmean **0.72** `[census]`.
- **Conventional Commits 1.0.0** `[lit]` (https://www.conventionalcommits.org/en/v1.0.0/). Census: `cc_adopted` **45/67** (behavioral commit sampling), `cc_ratio` wmean **0.60**, **+22** weighted-vs-uniform — fastest-rising ④ signal `[census]`. Independently re-validates the T1 (Conventional-Commits adoption) call on fresh evidence, not taste.
- **Keep a Changelog 1.1.0** `[lit]` (https://keepachangelog.com/en/1.1.0/). Census: `changelog` **55/52** `[census]`.
- **Releases / notes** `[census]`: `has_releases` **89/86** (coverage 100%), `has_release_notes` **88/85**. **Cadence** median **7 days** (n=378).
- **Deployment/ops half** `[census]`: `cd_deploy` **64/68**, `container` **53/62**, `iac` **28/29**, `observability` **18/17**.
- **DORA Four Keys + reliability** `[lit]` (https://dora.dev/guides/dora-metrics-four-keys/; https://cloud.google.com/devops). **State of DevOps 2024** cluster split: Elite **19%**, High **22%** (↓ from 31%), Low **25%** (↑ from 17%) (https://getdx.com/blog/2024-dora-report/); foundations: *Accelerate* (Forsgren et al. 2018), *Google SRE* (Beyer et al. 2016).
- **Observability/SLO surveys** `[lit]`: SLOs in production **~26%** (Grafana Observability Survey 2024, https://grafana.com/observability-survey/2024/); OpenTelemetry 58–85% — cross-validates the **17% observability-as-code** census (both: "monitoring/SLO maturity is a minority").
- **Census provenance** `[census]`: same 429-repo set as ② foundation, collected via GitHub Releases/Tags API + commit-message sampling + file-tree flags (mechanical, no LLM judgment); recency-weighted `w = 0.5^(age/2yr)`, ref 2026-06-24; 0 fetch failures, 5 tree truncations. Source `census-data/census-release-ops/`.

## Archetype variations

**Release discipline is universal; operational depth tracks "is there a running service?"** (per-archetype uniform %, `census-release-ops/stats.json`):

- **library** (n=93): releases/notes/SemVer **91/90/92**, but container **24**, iac **16**, obs **10**. ④ = "publish a versioned release." CC only 37.
- **cli** (n=77): **95/95/88** release, container 53, obs **8**. Like library + a binary publish step (e.g. goreleaser).
- **backend-service** (n=67): container **79**, cd 67, iac **42**, obs **31**, CC **54**. ④ = release **+** containerize **+** deploy **+** observe; PRRs/SLOs apply.
- **monorepo** (n=90): highest across the board — CC **71**, changelog **77**, container 68, iac **48**, obs **36**. Per-package versioning (changesets-style) + service-grade ops.
- **web-app** (n=33): release ~88, cd **70**, container 52, obs 9 — deploy-heavy, light on infra monitoring.
- **data-ml** (n=23): weakest release discipline (releases **65**, SemVer **43**, CC 17) — many are research repos, not shipped products; container 57 but obs 9.
- **mobile** (n=11): strong release/SemVer (91/82) but container 27, **obs 0** — store-submission pipeline, not server ops.

→ No archetype is *gated out* of release engineering, but the **operational half (container/CD/IaC/observability) is archetype-conditional** — selected by contract field **C5**. Mandating IaC/observability on a library is cargo-cult.

## Tradeoffs / what's ruled out

- **Behavioral sampling beats file-presence.** ②'s file proxy under-counted commit convention at 14% (commitlint *config* exists); commit-message sampling shows **45/67%** real practice. Evidence > proxy — but it costs an API sampling pass.
- **Observability stays `[lit]`, not a census gap.** Even in repos that *should* have it, observability-as-code is sparse (17%) because real monitoring/SLOs live in Datadog/Grafana/PagerDuty, not the tree. Don't try to "fill" it with a wider census — it's an honest `[lit]` posture line.
- **Operational *achievement* (SLO attainment, MTTR, change-failure rate) is irreducibly `[lit]`** — exists outside any repo; population numbers come from DORA-style **surveys**, not repo census. The harness *instruments toward* the Four Keys (release automation→frequency, CI+tests→low failure rate) but cannot census others' attainment.
- **Tool choice is `[lit]` default, not censused.** The census saw the *outcome* (a published GitHub Release), not whether it came from semantic-release / release-please / changesets / goreleaser; pick per ecosystem.
- **Ruled out:** manual version bumps, hand-written changelogs, manual release uploads, mandatory IaC/observability for non-service archetypes.

## Implications for gingoa

- **Release core is universal and scaffolded by default.** gingoa provisions SemVer tagging + a release-automation workflow (tagged GitHub Release + generated notes) + Conventional-Commits-driven changelog for **every** shipping archetype. This is already the gingoa contract: **US-5 Release/Ops** requires "SemVer + Conventional-Commits release automation, CHANGELOG, rollback path, supply-chain gates; DORA/SLO posture surfaced" (`docs/PRD.md` §C2). gingoa already dogfoods CC + Conventional-Commits PR titles (`CLAUDE.md` "Commits & PRs").
- **Operational half branches on archetype (contract C5).** The derived layer selects container/CD/IaC/observability-as-code only when the archetype runs a service — backend/monorepo get the full ops stack, library/cli get publish-only. This matches the census archetype split and avoids cargo-cult ops.
- **`[lit]` posture, not repo files, for the ops tail.** SLO definitions, runbooks, incident retros, on-call, DORA dashboards are *produced (literature) but not pushed to the public remote* — intrinsically off-repo and partly security-sensitive (publish-axis rule, `_schema.md` §4 (publish-axis)). observability-as-code (prometheus/otel config) ships as public config where archetype-relevant; **SLO targets / retros stay internal.**
- **Measurement target = DORA.** gingoa frames ④ quality against the Four Keys: release automation → deploy frequency (census proxy: weekly cadence), CI+tests → low change-failure rate, rollback path + observability → fast recovery. It instruments toward these without claiming to census attainment.
- **Rollback is a first-class gate.** A defined revert path (the `rollback`/`hotfix` skills) is required of every release, satisfying the contract's "rollback path" NFR and the DORA recovery lever.
- **Provenance + SRE artifact set (the ④ build-spec).** The full release+operate artifact checklist — the
  **supply-chain provenance half** (SBOM · SLSA provenance · Cosign signing · checksum manifest) this aspect
  is thin on, plus the **SRE/operate half** (SLO doc · error-budget policy · OTel three-pillars · burn-rate
  alerts · runbook-per-alert · blameless postmortem + action-item tracking · DORA instrumentation · vuln
  management) — is the ④ build-time spec: [`release-operate-artifact-checklist.md`](release-operate-artifact-checklist.md).
  It also grounds **aspect-18** (packaging/provenance) and **aspect-20** (operate) — the ④ items previously
  unbound to a mechanism.

## Sources

- SemVer 2.0.0 — https://semver.org/
- Conventional Commits 1.0.0 — https://www.conventionalcommits.org/en/v1.0.0/
- Keep a Changelog 1.1.0 — https://keepachangelog.com/en/1.1.0/
- DORA Four Keys — https://dora.dev/guides/dora-metrics-four-keys/
- DORA / DevOps research — https://cloud.google.com/devops
- State of DevOps 2024 analysis — https://getdx.com/blog/2024-dora-report/
- Grafana Observability Survey 2024 (SLO ~26%) — https://grafana.com/observability-survey/2024/
- Census: 429-repo Release/Tags-API + commit sampling — `census-data/census-release-ops/`
- *Accelerate* (Forsgren, Humble, Kim 2018) · *Site Reliability Engineering* (Beyer et al., Google 2016)

## Sub-documents
- [`release-operate-artifact-checklist.md`](release-operate-artifact-checklist.md) — *research-log* — the ④ release+operate artifact checklist: supply-chain provenance (SBOM/SLSA/cosign/checksum) + the SRE/operate half (SLO/error-budget/runbook/postmortem/OTel/DORA); also grounds aspects 18 & 20.
