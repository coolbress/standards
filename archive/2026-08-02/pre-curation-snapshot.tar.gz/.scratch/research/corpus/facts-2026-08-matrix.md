# 합성 매트릭스 — 2026-08 facts 패스의 주제별 교차 정리

> 성격: **코퍼스 접목된 facts sub-doc들의 교차 항해 문서.** 새 리서치 없음.
> 본문이 참조하는 번호(06–16)는 현재 다음 경로에 있다:
> 06→`aspects/28-…/facts-2026-08-sdlc-models.md` · 07→`aspects/01-…/facts-2026-08-requirements.md` ·
> 08→`aspects/02-…/facts-2026-08-design-practice.md` · 09→`aspects/07-…/facts-2026-08-codereview.md` ·
> 10→`aspects/08-…/facts-2026-08-testing.md` · 11→`aspects/04-…/facts-2026-08-cicd-release.md` ·
> 12→`aspects/20-…/facts-2026-08-operations-sre.md` · 13→`aspects/28-…/facts-2026-08-agile-adoption.md` ·
> 14→`aspects/09-…/facts-2026-08-security-sdlc.md` · 15→`aspects/01-…/facts-2026-08-estimation-failure-data.md` ·
> 16→`aspects/24-…/facts-2026-08-roles-teams.md` · (00–05 해석층 참조는 `../interpretation/`)
> 의견·판정 없음. 출처 간 수렴/상충은 "누가 무엇을 기술하는가"의 사실로만 기록한다.
> 각 항목의 원 출처 URL은 해당 파일에 있다. (해석 층 00–04의 관련 위치는 참고 포인터로만 표기)

## 주제 × 파일 매핑

| 주제 | 사실 층 근거 | 해석 층 참고 |
|---|---|---|
| A. 라이프사이클 모델·단계 | 06, 13 | 01 |
| B. 요구사항·스펙 | 07 | 03 |
| C. 설계 문서·결정 기록 | 08 | 03 |
| D. 작업 분해·첫 조각 | 07, 08 | 03 |
| E. 구현·통합·git 워크플로우 | 09, 11 | 02 |
| F. 코드리뷰 | 09 | 02 |
| G. 테스트 | 10 | 02 |
| H. 완료 정의·검증 게이트 | 13, 11, 09 | 02 |
| I. 릴리스·배포 | 11 | 01, 02 |
| J. 운영·모니터링·사고 대응 | 12 | 01 |
| K. 추정·스코프·프로젝트 성패 | 15, 07, 13 | 03 |
| L. 역할·팀 구조 | 16 | 01 |
| M. 보안 | 14 | 04 |
| N. AI의 영향 | 15, 14 | 04 |
| O. 방법론 채택 통계 | 13, 11 | 01 |

---

## A. 라이프사이클 모델·단계

- [정의/규정] Royce(1970)는 7단계 순차 모델을 그리되, 분석·코딩 2단계만으로는 "실패할 수밖에 없다"고 쓰고 프로토타입에 일정의 1/4~1/3 투자, 코드 리뷰, 독립 테스트 조직을 처방 (06). Royce는 waterfall이라는 용어를 쓰지 않았고 선형 모델을 옹호하지 않았다 (06).
- [정의/규정] V-model은 개발 단계마다 대응 테스트 단계의 선행 설계를, Spiral(Boehm)은 루프마다 위험 분석을, RUP는 4단계×9훈련의 반복을, ISO 12207은 방법론 중립의 프로세스 분류를, CMMI는 5성숙도 단계를 규정 (06).
- [정의/규정] Continuous Delivery는 "항상 배포 가능 상태" 유지와 테스트의 비(非)단계화("테스트를 별도 단계로 분리하지 않는다")를 규정 (06).
- [정의/규정] Agile Manifesto 4가치·12원칙 — 짧은 주기의 동작 소프트웨어 전달, 동작 소프트웨어가 진도의 주요 척도 (06, 13).

## B. 요구사항·스펙

- [정의/규정] ISO/IEC/IEEE 29148: 요구사항의 특성·속성 정의, 생명주기 전체의 반복적 적용 (07).
- [정의/규정] 3C(Card/Conversation/Confirmation — Jeffries/Cohn), INVEST(Wake 2003), GWT(BDD) 인수기준 형식 (07).
- [주장] Cohn: "user story는 미래 대화를 위한 플레이스홀더" (07). Wake: Testable = "테스트를 쓸 수 있을 만큼 이해했다는 암묵적 약속" (07).
- [정의/규정] Mom Test 3규칙: 아이디어 피치 금지 / 과거의 구체적 행동 질문 / 적게 말하기 (07).
- [정의/규정] Shape Up pitch 5요소(Problem·Appetite·Solution·Rabbit Holes·No-gos); Appetite는 "추정이 아니라 제약조건", 2주 또는 6주 (07, 13).
- [데이터] Lenny 템플릿 조사: "문제 정의가 가장 중요한 단계", 1-pager 중심, 문제 이해와 솔루션 설계 분리 (07). Amazon PR/FAQ 구조(보도자료 1~1.5쪽 + 내외부 FAQ) (07).

## C. 설계 문서·결정 기록

- [정의/규정] Google design doc(Ubl) 6섹션: 메타 / 컨텍스트·범위·목표 / 개요 / 상세 / 교차 문제(보안·성능·모니터링) / **검토된 대안** (08).
- [정의/규정] Nygard ADR 5섹션: Title / Status / Context / Decision / Consequences (08).
- [데이터] RFC 실무: Uber(소규모 도입→수천 명 스케일, 서비스/모바일별 항목), Spotify(비기술 변경에도 사용), Sourcegraph(Summary·Background·Problem·Proposal·**Definition of Success** 5개뿐) (08).
- [주장] Pragmatic Engineer: "문서 작성이 잠재된 이견을 드러낸다" (08).
- [정의/규정] C4: Context→Container→Component→Code 4계층 (08).

## D. 작업 분해·첫 조각

- [정의/규정] Walking Skeleton(Cockburn): "작은 end-to-end 기능을 수행하는 작은 구현"; 최종 아키텍처일 필요는 없으나 주요 컴포넌트를 연결 (08).
- [정의/규정] Tracer Bullet(Hunt/Thomas): "불완전하지만 완결된" 골격 — 프로토타입(폐기용)과 달리 프로덕션으로 진화 (08).
- [정의/규정] INVEST의 V: 아키텍처 단일 계층이 아닌 수직 분할을 권장한다고 기술 (07).

## E. 구현·통합·git 워크플로우

- [정의/규정] Fowler CI: 일일 최소 통합, ~10분 빌드, 자기검증 빌드, 단일 mainline (11).
- [정의/규정] Trunk-based: 브랜치 수명 시간 단위, 24시간마다 최소 1회 trunk 커밋 (09). Git Flow=다중 브랜치, GitHub Flow=main+단기 브랜치 (09).
- [데이터] Google 모노레포 운영 — 09의 출처는 "35,000명 개발자", 11의 출처는 "수만 명"으로 기술 (수치 표현이 출처마다 다름). Android·Chrome은 멀티레포 (11).
- [정의/규정] Conventional Commits: type(scope): description, feat→MINOR/fix→PATCH/!→MAJOR (09, 11의 SemVer와 연결).

## F. 코드리뷰

- [정의/규정] Google: "완벽하지 않아도 코드 건전성을 명확히 개선하면 승인 선호"; 100줄 적정/1000줄 과대; 크기만으로 반려 재량; CL 첫 줄은 명령형 요약 (09).
- [데이터] ICSE 2018(Google 실측): 80% 이상의 변경이 반복 1회 이하, 리뷰어 보통 1명 (09).
- [데이터] SmartBear/Cisco: 200–400 LOC를 60–90분에 리뷰 시 결함 70–90% 발견; 300 LOC/h 이하가 최적 (09).
- [데이터] Bacchelli & Bird(Microsoft 2013): 개발자는 결함 발견을 주목적으로 여기나, 실제 가치는 지식 이전·팀 인식·대안 창출이 더 흔함 (09).
- [데이터] 페어 프로그래밍: +15% 시간/−15% 결함(유타대), "페어는 결함 85–95% 발견 vs 형식 리뷰 60–70%"(tuple.app 정리, 2차) (09).

## G. 테스트

- [정의/규정] 피라미드(Cohn 원형, Fowler 정리): 하위 다수·상위 소수, 중복 제거 (10).
- [데이터] Google 테스트 크기 분류(small/medium/large)와 80/15/5 비율; flaky ~0.15% 유지, 1% 접근 시 신뢰 상실 (10). ※ Fowler 정리 계열에서는 ~70/20/10 비율 표현도 등장 — 출처 간 수치 표현 상이 (10).
- [주장] Google Testing Blog: E2E 편중 반대("Just Say No to More End-to-End Tests") (10).
- [주장] Dodds(Testing Trophy): 통합 테스트가 확신 대비 비용 최적; 커버리지 100% 추구는 수확 체감 (10).
- [데이터] TDD 실증(메타분석·Fucci et al.): 생산성에 통계적 유의 효과 없음, test-first 순서 자체는 유의미하지 않고 잘게·균일한 스텝이 관련 (10).
- [데이터] Google mutation testing: 6,000명 엔지니어의 코드리뷰 시점에 운영 (10).

## H. 완료 정의·검증 게이트

- [정의/규정] Scrum Guide: Definition of Done = "증분이 요구 품질 기준을 충족한 상태의 공식 기술"; 미충족 작업은 릴리스 불가 (13).
- [정의/규정] Continuous Delivery: "언제든 배포 가능 상태"를 파이프라인이 상시 검증 (11, 06).
- [정의/규정] Google 리뷰 항목에 "변경과 함께 오는 유효한 테스트" 포함 (09).

## I. 릴리스·배포

- [정의/규정] Delivery(수동 승인 잔존) vs Deployment(전자동) 구분 (11).
- [정의/규정] Feature toggle 4분류(Release/Experiment/Ops/Permissioning); Fowler는 release flag를 "마지막 수단"으로, Keystone Interface 우선을 기술 (11).
- [정의/규정] Blue-green(즉시 롤백), Canary(점진 노출) (11).
- [정의/규정] SemVer MAJOR.MINOR.PATCH 규칙; Release Train("기차는 기다리지 않음"), SAFe ART(50–125명) (11).
- [데이터] DORA 2024: Elite는 Low 대비 리드타임 127배, 배포 182배, 실패율 8배 낮음, 복구 2,293배 (11, 2차 경유).

## J. 운영·모니터링·사고 대응

- [정의/규정] SLI/SLO/Error Budget 정의; toil 6특성; SRE 시간 배분(엔지니어링 ≥50%, on-call ≤25%); 24/7 커버리지 최소 인원 8명(단일 사이트) (12).
- [정의/규정] 사건 대응 4역할(IC/OL/CL/PL); blameless postmortem("사람은 고칠 수 없지만 시스템·프로세스는 고칠 수 있다") (12).
- [정의/규정] Golden Signals 4가지(Latency/Traffic/Errors/Saturation); observability 3요소(Metrics/Logs/Traces — Elastic 정의) (12).
- [데이터] DevOps 기원: 2009 Flickr "10+ Deploys per Day" 발표, Debois의 Devopsdays (12).

## K. 추정·스코프·프로젝트 성패

- [데이터] CHAOS 연도별 성패율(1994 성공 16% → 2020 성공 31%), 소규모>대규모 성공률 (15). — 병기: Eveleens & Verhoef는 CHAOS 정의의 4결함을 지적하고 5,457개 예측 데이터로 괴리를 보임 (15).
- [데이터] McKinsey-Oxford($15M+ 5,400개): 비용 초과 평균 45%, 가치 미달 56%, 17%는 회사 존속 위협 (15).
- [주장/데이터] Boehm 곡선($1→…→50–200배)과 2001년 Boehm·Basili의 완화 보고(소규모/agile ≈5:1) (15).
- [정의/규정] Cone of Uncertainty(McConnell); [주장] 초기 추정의 재보정이 실무에서 거의 없음 (15).
- [데이터] Jørgensen 계열: 프로젝트 60–80%가 초과 경험, 평균 초과 30–40%; 추정의 83–84%는 전문가 판단; 닻 효과 ~2배; 수십 년간 정확도 개선 없음 (15).
- [데이터] PMI 2018: 52%가 scope creep 경험 (15).
- [정의/규정] Shape Up: appetite(시간 고정·범위 가변), circuit breaker(자동 연장 없음), 백로그 거부 (13, 07).
- [주장] Brooks "No Silver Bullet": 어떤 단일 기법도 한 자릿수 개선을 약속 못 함 (15).

## L. 역할·팀 구조

- [정의/규정] PM(왜·무엇) / PO(백로그·전달) / Project Manager(어떻게·언제) 구분 (16).
- [정의/규정] 공개 래더: GitLab IC 트랙(Engineer→…→Fellow, 관리 트랙과 등가 매핑), Dropbox Core Responsibilities (16).
- [정의/규정] Team Topologies 4팀 유형·3상호작용 모드; Conway's Law 원문(1968 Datamation) (16).
- [데이터] QSM: 최적 팀 3–7명(최고 5–7명); 9명+ 팀은 일정 −30%에 비용 +350%, 결함 +500% (16).
- [주장] Spotify model 저자들: "20% 구조, 80% 문화… 원 모델은 더 이상 우리 방식과 맞지 않음"(2019) (16).
- [정의/규정] Dual-track(Cagan/Patton): 발견=검증된 백로그 생성, 전달=릴리스 소프트웨어 생성, 같은 팀의 병렬 (16).

## M. 보안

- [정의/규정] OWASP Top 10:2025(1위 Broken Access Control), ASVS(~350 요구사항), SAMM, Microsoft SDL 5단계, STRIDE, SLSA L0–L3, 12-factor config, GitHub secret scanning (14).
- [데이터] Verizon DBIR 2026: 취약점이 초기 접근 벡터 1위(31%), 중간 패치 시간 32→43일 (14).
- [데이터] CVE-2025-48757(Lovable): RLS 부재로 1,645개 중 170개 앱(≈10%) 취약, 사후 RLS 기본값화 (14).

## N. AI의 영향

- [데이터] (Faros AI 블로그의 DORA 2025 정리 — 2차, 문서 내 주의 표기) AI 도구 사용 95%, 개인 작업 완료 +21~34%; 조직 지표는 정체/악화, 버그 +54%, PR당 사고 +242.7%, 리뷰 시간 +441% (15).
- [데이터] AI 생성 코드의 보안 부채가 정규 코드의 5배 초과라는 연구 보고(CSA) (14).

## O. 방법론 채택 통계

- [데이터] State of Agile 2026(staragile 경유, 2차): Scrum ~70%, Kanban ~50%; 조사 통합 범위는 Scrum 63–87% (13).
- [데이터] PMI Pulse 2024: Hybrid 20→31%(2020–2023), Predictive −24%; PMI 기술 — "세 접근법 모두 비슷한 성과 제공 가능" (13).
- [데이터] CI 도구(JetBrains 2025): GitHub Actions 33% > Jenkins 28% > GitLab CI 19% (조직 기준) (11).

---

## 출처 간 수치·표현 상이 목록 (교차 검증 대상)

| 항목 | 상이 내용 | 파일 |
|---|---|---|
| Google 모노레포 개발자 수 | "35,000명" vs "수만 명" — 출처·시점 상이 | 09 / 11 |
| 테스트 비율 | Google 80/15/5 vs Fowler 계열 ~70/20/10 표현 | 10 |
| Scrum 채택률 | 단일 조사 ~70% vs 조사 통합 63–87% | 13 |
| CHAOS 수치 | 수치 자체(15) vs 방법론 비판(Eveleens&Verhoef, 15) 병존 | 15 |
| Boehm 곡선 | 원 주장(최대 200배) vs 2001 완화(≈5:1, 소규모) | 15 |
| DORA 수치의 경유 | Elite/Low 배수·AI 영향 수치가 2차 사이트 경유 | 11, 15 |
| PMI 2024 표현 | 채택 분포(예측 44/하이브리드 32/애자일 26 — 해석층 01)와 추세(+/−% — 사실층 13)가 다른 절단면 | 01 / 13 |

## 1차 출처 재확인 우선 대상 (결론 작성 전)

수치가 결론의 근거로 쓰일 가능성이 높으면서 현재 2차 경유인 것: DORA 배수·클러스터(→ dora.dev 원문), CHAOS 연도별 수치(→ Standish 원문/학술 정리), State of Agile 채택률(→ digital.ai 원문), AI 영향 수치(→ DORA 2025 원문), 페어 프로그래밍 결함 발견율(→ 원 논문), McKinsey 수치(→ mckinsey.com 원문 — 해석층 01에는 1차 링크 있음).
