# corpus/ — 승계 기록 (PROVENANCE)

- **원본**: `~/gingoa/docs/research/` (gingoa 하네스의 엔지니어링 표준 코퍼스)
- **이관일**: 2026-08-02 · 이관 방식: 파일 사본 (원본 저장소는 무수정 보존)
- **이관 범위**: INDEX.md · _schema.md · TAXONOMY.md · lifecycle.md · GUIDE.ko.md · three-tier-ledger.md · aspects/ (28개 aspect + sub-docs, 82 md) · census-data/ (불변 원시 증거)
- **상태**: 이관 직후 — 내용은 gingoa 시점(2026-06) 그대로. `gingoa_applied:` frontmatter, "Implications for gingoa" 섹션 등 gingoa 종속 표기가 남아 있음.

## goppi_final에서의 지위

이 코퍼스가 goppi_final 리서치의 **본체(표준 층)**다. 28-aspect 분류는 SWEBOK·ISO 12207·25010·29148·OWASP·SLSA·DORA·SRE 등에 앵커되어 4각 심층 리서치로 잠금(locked)됐고(TAXONOMY.md), 스키마·증거 태그(`[lit]/[census]/[inferred]`)·상태 라이프사이클은 `_schema.md`가 규정한다. 새 리서치는 루트에 흩어두지 않고 이 코퍼스의 해당 aspect에 접목한다(§3b).

## 승계 후 적응 (상태 추적)

- [x] **2026-08-02 facts 층 접목 완료** — 11개 파일이 `facts-2026-08-*.md`로 각 aspect에 편입(§3a frontmatter, `kind: research-log`, `language: ko`), `_aspect.md` Sub-documents + INDEX deep-dive에 링크. 매트릭스는 corpus 루트 `facts-2026-08-matrix.md`(경로 매핑 헤더 포함).
- [ ] gingoa 종속 표기 정리: `gingoa_applied:` 필드 → `applied:`(goppi_final 경로)로, "Implications for gingoa" 섹션 → 유지하되 goppi_final 관점 주석 추가 (내용 삭제 금지 — 역사 보존)
- [ ] `../imported/`의 과거 리서치 접목 (imported/README.md의 "다음 처리")
- [ ] 시효 점검: census(2026-06 수집)와 시장 스냅샷의 만료 여부 — 각 문서의 `last_updated`와 status로 판단
- [ ] 태그 체계 통일: facts sub-doc의 `[정의/규정]/[데이터]/[주장]`+`[1차]/[2차]` ↔ corpus `[lit]/[census]/[inferred]` — 접목 문서의 frontmatter `method`가 현 체계를 명시하므로 급하지 않음
- [ ] 부차 aspect 교차 링크: 09→05(scm), 11→17(release), 12→19(observability), 14→10(supply-chain), 16→23(devex) — 현재는 각 entry의 "also serves" 문구로만 표시

## facts(06–16) → 실제 편입 위치

| 원 파일 | 현재 경로 |
|---|---|
| 06 | `aspects/28-implementation-process-workflow/facts-2026-08-sdlc-models.md` |
| 07 | `aspects/01-requirements-planning/facts-2026-08-requirements.md` |
| 08 | `aspects/02-architecture-design/facts-2026-08-design-practice.md` |
| 09 | `aspects/07-construction-code-review/facts-2026-08-codereview.md` |
| 10 | `aspects/08-software-testing/facts-2026-08-testing.md` |
| 11 | `aspects/04-build-ci-engineering/facts-2026-08-cicd-release.md` |
| 12 | `aspects/20-operations-incident-reliability/facts-2026-08-operations-sre.md` |
| 13 | `aspects/28-implementation-process-workflow/facts-2026-08-agile-adoption.md` |
| 14 | `aspects/09-application-security/facts-2026-08-security-sdlc.md` |
| 15 | `aspects/01-requirements-planning/facts-2026-08-estimation-failure-data.md` |
| 16 | `aspects/24-governance-collaboration-compliance/facts-2026-08-roles-teams.md` |
| 17 | `facts-2026-08-matrix.md` (corpus 루트) |
