# Gingoa Engineering-Standard Corpus — INDEX

> **Agent entry point. Read this first.** The "how do senior engineers do it" reference gingoa consults
> while building. Use the summaries to fetch only the aspect doc(s) relevant to the current task — do not
> load everything. Conventions & frontmatter spec: [`_schema.md`](_schema.md). Korean reader's guide:
> [`GUIDE.ko.md`](GUIDE.ko.md). Locked aspect set & rationale: [`TAXONOMY.md`](TAXONOMY.md). Stage→aspect
> activation: [`lifecycle.md`](lifecycle.md). Raw evidence: `census-data/`.

## P — Plan & Design
- [`01` Requirements & Planning](aspects/01-requirements-planning/_aspect.md) — elicitation (Socratic) · functional + NFR (ISO-25010 sweep) · 29148 quality (full §5.2.5–5.2.6 well-formedness set) · EARS acceptance. _anchors:_ SWEBOK-KA1, ISO-29148, PMBOK7-Uncertainty.
- [`02` Architecture & Design](aspects/02-architecture-design/_aspect.md) _(cross-cutting)_ — architectural styles (layered/microservice/event/hexagonal) · ADRs (cross-cutting) · quality-attribute tactics. _anchors:_ SWEBOK-KA2, SWEBOK-KA3, ISO-12207-Architecture.

## F — Foundation & Build
- [`03` Dev Environment & Local Setup](aspects/03-dev-environment/_aspect.md) — reproducible local env (devcontainer/mise/Nix) · editorconfig · dev/prod parity & environment management. _anchors:_ SWEBOK-KA4, 12-Factor-I/II/X, devcontainer.
- [`04` Build & CI Engineering](aspects/04-build-ci-engineering/_aspect.md) _(cross-cutting)_ — CI pipeline (lint·typecheck·test·build) · build graph / affected (monorepo) · caching. _anchors:_ SWEBOK-KA4, SWEBOK-KA6, Accelerate.
- [`05` SCM & Development Workflow](aspects/05-scm-workflow/_aspect.md) _(cross-cutting)_ — branching (trunk / GitHub-flow) · Conventional Commits · CODEOWNERS. _anchors:_ SWEBOK-KA8, DORA-trunk, Conventional-Commits.
- [`06` Configuration & Secrets Management](aspects/06-config-secrets/_aspect.md) _(cross-cutting)_ — typed config + startup validation · feature flags · secret stores / rotation. _anchors:_ 12-Factor-III, NIST-SP-800-53-IA.

## C — Construct & Verify
- [`07` Software Construction & Code Review](aspects/07-construction-code-review/_aspect.md) — coding standards · code review (CL size / duties) · TDD. _anchors:_ SWEBOK-KA4, Google-eng-practices.
- [`08` Software Testing](aspects/08-software-testing/_aspect.md) _(cross-cutting)_ — unit / integration / e2e · contract testing (Pact) · property / mutation. _anchors:_ SWEBOK-KA5, ISO-25010, test-pyramid.
- [`09` Application Security](aspects/09-application-security/_aspect.md) _(cross-cutting)_ — threat modeling (STRIDE / DFD) · secure-by-design · authn / authz. _anchors:_ SWEBOK-KA13, OWASP-SAMM, OWASP-ASVS.
- [`10` Software Supply Chain Security](aspects/10-supply-chain-security/_aspect.md) _(cross-cutting)_ — SBOM (CycloneDX / SPDX) · provenance / attestation · artifact signing. _anchors:_ NIST-SSDF-PS, SLSA-v1.0, OpenSSF-Scorecard.
- [`28` Implementation Process & Agentic Workflow](aspects/28-implementation-process-workflow/_aspect.md) — risk/size process tailoring (tiering) · plan-then-act (plan as artifact) · lead-coordinator + context-isolated subagents. _anchors:_ SWEBOK-Process-KA, SWEBOK-Management-KA, ISO-12207-Tailoring.

## Q — Quality Attributes
- [`11` Maintainability, Tech Debt & Refactoring](aspects/11-maintainability-techdebt-refactoring/_aspect.md) _(cross-cutting)_ — debt register (ADR-tagged) · complexity / coupling metrics · refactoring discipline (Boy-Scout / strangler). _anchors:_ SWEBOK-KA7, ISO-25010-Maintainability.
- [`12` Performance & Scalability](aspects/12-performance-scalability/_aspect.md) _(gated: web, backend, data-ml, mobile, library)_ — perf budgets / benchmark · profiling · load / stress. _anchors:_ ISO-25010-Performance, ISO-25010-Flexibility, SRE-capacity.
- [`13` API & Interface Design](aspects/13-api-interface-design/_aspect.md) _(gated: library, cli, backend)_ — REST / GraphQL / gRPC design · versioning & breaking-change gate · idempotency. _anchors:_ SWEBOK-KA2, SWEBOK-KA3, OpenAPI.
- [`14` Data Management & Migrations](aspects/14-data-management-migrations/_aspect.md) _(gated: backend, data-ml)_ — schema / data migrations (Flyway/Alembic) · zero-downtime / expand-contract · data modeling. _anchors:_ ISO-12207-Implementation, ISO-12207-Maintenance, expand-contract.
- [`15` Accessibility & UX / Interaction Capability](aspects/15-accessibility-ux/_aspect.md) _(gated: web, mobile)_ — WCAG POUR / AA · semantic HTML / ARIA · keyboard / screen-reader. _anchors:_ ISO-25010-Interaction-Capability, WCAG-2.2, EN-301-549.
- [`16` Privacy & Data Protection](aspects/16-privacy-data-protection/_aspect.md) _(gated: handles-user-data)_ — privacy-by-design · data minimization · DSAR / erasure / portability. _anchors:_ GDPR-Art-25, ISO-25010-Security, NIST-Privacy.

## R — Release & Operate
- [`17` Release Engineering](aspects/17-release-engineering/_aspect.md) — SemVer · changelog automation · CI/CD gates. _anchors:_ SemVer-2.0, Conventional-Commits, Keep-a-Changelog.
- [`18` Packaging & Distribution](aspects/18-packaging-distribution/_aspect.md) — registry publish (npm/PyPI/crates/Maven) · binary distribution (Homebrew/winget/goreleaser) · container / Helm publish. _anchors:_ npm-provenance, SLSA, Homebrew.
- [`19` Observability & Telemetry](aspects/19-observability-telemetry/_aspect.md) — metrics (RED / USE) · structured logs · distributed tracing. _anchors:_ OpenTelemetry, SRE-golden-signals.
- [`20` Operations, Incident & Reliability](aspects/20-operations-incident-reliability/_aspect.md) — SLO + error-budget policy · on-call / escalation · incident response. _anchors:_ Google-SRE, ITIL-4, DORA.
- [`21` Software Economics, Cost & Sustainability](aspects/21-economics-cost-sustainability/_aspect.md) _(gated: cloud, published)_ — cost visibility / tagging · budget alerts · rightsizing / commitments. _anchors:_ SWEBOK-KA15, FinOps-Framework, GSF-SCI.

## G — Cross-cutting Practice & Governance
- [`22` Documentation & Knowledge Management](aspects/22-documentation-knowledge/_aspect.md) _(cross-cutting)_ — Diátaxis 4-mode · README / CONTRIBUTING / SECURITY / CHANGELOG · ADR records. _anchors:_ Diataxis, IEEE-ISO-15289, docs-as-code.
- [`23` Developer Experience & Onboarding](aspects/23-developer-experience/_aspect.md) _(cross-cutting)_ — onboarding runbook · time-to-first-PR · golden paths / paved road. _anchors:_ CNCF-Platform-Eng-MM, DORA-platform, SPACE.
- [`24` Governance, Collaboration & Compliance](aspects/24-governance-collaboration-compliance/_aspect.md) _(cross-cutting)_ — issue / triage · contribution policy / CoC · decision rights (RACI). _anchors:_ ISO-12207-Org, SWEBOK-KA9, SWEBOK-KA14.
- [`25` Licensing & FOSS Compliance](aspects/25-licensing-foss-compliance/_aspect.md) _(cross-cutting)_ — license selection / compatibility (inbound/outbound) · SPDX identifiers / REUSE · dependency license scanning. _anchors:_ SPDX-2.3, REUSE-2.0, OpenChain-ISO-5230.

## S — Specialized Archetype
- [`26` MLOps / ML Lifecycle](aspects/26-mlops-ml-lifecycle/_aspect.md) _(gated: data-ml)_ — data versioning (DVC / Delta) · experiment tracking (MLflow / W&B) · feature store (Feast). _anchors:_ ml-ops.org-Stack-Canvas, MLOps-literature.
- [`27` AI-Harness Archetype](aspects/27-ai-harness-archetype/_aspect.md) _(internal / gated: ai-harness)_ — agent orchestration (planner / impl / review) · prompt engineering + versioning · evals / eval-harness. _anchors:_ Anthropic-MCP, Agent-Skills, AGENTS.md.

## Deep-dive sub-documents (fetch when an aspect needs depth — these are the definitive standards)
- **01 Requirements & Planning** — [`planning-document-family`](aspects/01-requirements-planning/planning-document-family.md) (the PRD/spec doc KINDS · sections · naming · location · publish) · [`decision-record-standard`](aspects/01-requirements-planning/decision-record-standard.md) (ADR sections + IS/ISN'T-an-ADR rubric) · [`elicitation-interview-build-standard`](aspects/01-requirements-planning/elicitation-interview-build-standard.md) (the US-2 interview-engine build standard, 7 prior-art families) · [`requirements-engineering-craft`](aspects/01-requirements-planning/requirements-engineering-craft.md) (traceability · validation · DoR · prioritization) · [`constitution-authoring-standard`](aspects/01-requirements-planning/constitution-authoring-standard.md) (`AGENTS.md`/`CLAUDE.md`) · [`elicitation-prior-art`](aspects/01-requirements-planning/elicitation-prior-art.md) · [`planning-output-census`](aspects/01-requirements-planning/planning-output-census.md) (*census*: 267-repo planning-artifact prevalence) · [`brownfield-planning-adoption`](aspects/01-requirements-planning/brownfield-planning-adoption.md) (the `adopt` ①-plan slice: import / convert / reverse-engineer existing requirements)
- **04 Build & CI** — [`foundation-floor-artifact-checklist`](aspects/04-build-ci-engineering/foundation-floor-artifact-checklist.md) (**the canonical ② foundation output contract**: floor file set × location × push × repo-context conditioning — the ② analogue of `planning-document-family`) · [`visibility-provision-matrix`](aspects/04-build-ci-engineering/visibility-provision-matrix.md) (private↔public enablement flips) · [`brownfield-adoption-floor`](aspects/04-build-ci-engineering/brownfield-adoption-floor.md) (the `adopt` ②-foundation slice: audit-mode · 3-way disposition · ownership baseline · relaxed green-gate)
- **17 Release** — [`release-operate-artifact-checklist`](aspects/17-release-engineering/release-operate-artifact-checklist.md)
- **22 Documentation** — [`content-ci-linting-and-jargon-gate`](aspects/22-documentation-knowledge/content-ci-linting-and-jargon-gate.md)
- **27 AI-Harness** — [`skill-authoring-standard`](aspects/27-ai-harness-archetype/skill-authoring-standard.md) · [`mcp-server-standard`](aspects/27-ai-harness-archetype/mcp-server-standard.md) (MCP Tools/Resources/Prompts · transports · security · ACI tool-design) · [`hooks-commands-subagents-standard`](aspects/27-ai-harness-archetype/hooks-commands-subagents-standard.md) (hooks events/security · commands→skills · subagent context-isolation · when-to-use matrix) · [`plugin-marketplace-memory-standard`](aspects/27-ai-harness-archetype/plugin-marketplace-memory-standard.md) (plugin.json/marketplace.json schemas · curation · CLAUDE.md + auto-memory + memory-tool · context-engineering) · [`prompts-and-evals-standard`](aspects/27-ai-harness-archetype/prompts-and-evals-standard.md) (prompt technique-ladder + Claude-4.x/GPT-5 specifics · prompts-as-source/versioning · eval-harness graders + LLM-judge + statistical rigor · prompt↔eval CI loop) · [`host-config-schemas`](aspects/27-ai-harness-archetype/host-config-schemas.md)
- **28 Implementation** — [`research-log`](aspects/28-implementation-process-workflow/research-log.md) (the process / agentic-workflow `[lit]` backbone)
- **2026-08 facts pass (ko)** — eleven facts-only sub-docs (`facts-2026-08-*.md`, per-claim URLs + source-tier tags) folded into aspects 01(×2)·02·04·07·08·09·20·24·28(×2); cross-aspect navigation + figure-discrepancy list: [`facts-2026-08-matrix.md`](facts-2026-08-matrix.md)

---
_All 28 aspects are fully curated + hand-maintained (no longer skeletons). Each aspect's own `## Sub-documents` section is authoritative for its deep dives._
